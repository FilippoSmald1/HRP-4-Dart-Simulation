/*
 * Utility.hpp
 *
 *  Created on: Jul 4, 2017
 *      Author: vale
 */

#ifndef UTILITY_HPP_
#define UTILITY_HPP_

#include  <fstream>
#include  <vector>
#include  <iostream>
#include  <sstream>
#include  <string>

bool readFile(std::string name_file,std::vector < std::vector<double> > & data);



#endif /* UTILITY_HPP_ */
